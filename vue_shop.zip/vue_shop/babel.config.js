//这是项目发布阶段需要用到的babel插件
const prodPlugins = []
//判断编译模式
if(process.env.NODE_ENV === 'production'){
  prodPlugins.push('transform-remove-console')
}

module.exports = {
  presets: [
    "@vue/app"
  ],
  "plugins": [
    [
      "component",
      {
        "libraryName": "element-ui",
        "styleLibraryName": "theme-chalk"
      }
    ],
    //...展开运算符：把数组中的每一项展开放在另一个数组中
    //发布产品时的插件数组
    ...prodPlugins,
    //配置路由懒加载的差价
    '@babel/plugin-syntax-dynamic-import'
  ]
}